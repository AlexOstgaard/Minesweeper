import pygame
import sys
import random
w_height = 800
w_width = 1600
blockSize = 40
ruteliste = []
rader = []
mines = []
sjekkeKø = []
sjekketRuter = []
alleFlag = []
åpneRuter = []
førsteKlikk = 0

for x in range(1, w_width, blockSize):
    hverRad = []
    for y in range(1, w_height, blockSize):
        hverRad.append((x, y)) 
    rader.append(hverRad)

for x in range(160):
    while True:
        y_koordinat = random.randint(0, len(rader)-1)
        currentRad = rader[y_koordinat]
        x_koordinat = random.randint(0, len(currentRad)-1)
        currentMine = currentRad[x_koordinat]

        if currentMine not in mines:
            mines.append(currentMine)
            break


def main():
    global SCREEN, CLOCK
    pygame.init()
    SCREEN = pygame.display.set_mode((w_width, w_height))
    CLOCK = pygame.time.Clock()
    SCREEN.fill("dark gray")
    

    while True:
        drawGrid()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x = pygame.mouse.get_pos()
                if event.button == pygame.BUTTON_LEFT:
                    finnRute(mouse_x)
                if event.button == pygame.BUTTON_RIGHT:
                    flag(mouse_x)
        pygame.display.update()

def drawGrid():

    for x in range(0, w_width, blockSize):
        for y in range(0, w_height, blockSize):
            rect = pygame.Rect(x, y, blockSize, blockSize)
            pygame.draw.rect(SCREEN, "black", rect, 1)

def fyllRute(a, b):
    rect = pygame.Rect(a, b, blockSize, blockSize)
    pygame.draw.rect(SCREEN, "white", rect)
    minerRundt = 0
    for i in range(-1, 2):
        for j in range(-1, 2):
                if ((a+40*i, b+40*j)) in mines:
                    minerRundt += 1
                    
    if minerRundt > 0:
        pygame.draw.rect(SCREEN, "light gray", rect)
        myFont = pygame.font.SysFont("Arial", 25)
        SCREEN.blit(myFont.render(str(minerRundt), True, (0, 0, 0)), (a, b))
    åpneRuter.append((a, b))


def førsteSafe(a):
    for i in range(-1, 2):
        for j in range(-1, 2):
                if ((a[0]+40*i, a[1]+40*j)) in mines:
                    mines.remove((a[0]+40*i, a[1]+40*j))
    klikketRute(a)

def klikketRute(a):
    
    knatX = a[0]
    knatY = a[1]

    if (knatX, knatY) in åpneRuter:
        åpneMines = 0
        åpneFlag = 0
        bom = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (knatX+i*40, knatY+j*40) in mines:
                    åpneMines+= 1
                if (knatX+i*40, knatY+j*40) in alleFlag:
                    åpneFlag+= 1 
                if åpneMines != åpneFlag:
                    bom += 1
        if åpneMines == åpneFlag:
            if bom == 0:
                sjekkRuterRundt(knatX, knatY)
            else: 
                pygame.quit()
    else:
        fyllRute(knatX, knatY)
        minerRundt = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                    if ((knatX+40*i, knatY+40*j)) in mines:
                        minerRundt += 1          
    
        if minerRundt == 0 and ((knatX, knatY)) not in sjekketRuter:
    
            sjekkRuterRundt(knatX, knatY)

    while len(sjekkeKø) > 0:
        sjekkRuterRundt(sjekkeKø[0][0], sjekkeKø[0][1])
        sjekkeKø.pop(0)

def sjekkRuterRundt(a, b):
    sjekketRuter.append((a, b))
    
    for i in range(-1, 2):
            for j in range(-1, 2):
                if ((a+i*40, b+j*40)) not in alleFlag:
                    fyllRute(a+i*40, b+j*40)
                
                sjekkmines = 0
                for k in range(-1, 2):
                    for l in range(-1, 2):
                        if ((a+40*i+40*k, b+40*j+40*l)) in mines:
                            sjekkmines +=1
                if sjekkmines == 0 and ((a+40*i, b+40*j)) not in sjekketRuter and 0<a+40*i<1562 and 0<b+40*j<790 and (a+40*i, b+40*j) not in sjekkeKø:
                    sjekkeKø.append((a+40*i, b+40*j))
                     
       
def finnRute(a):
    global førsteKlikk
    knater = rader[a[0]//blockSize][a[1]//blockSize]
    if førsteKlikk == 0:
        førsteKlikk = 1
        førsteSafe(knater)
    else:
        if knater not in alleFlag:
            if knater not in mines: 
                klikketRute(knater)
            if knater in mines:
                pygame.quit()
    
        

def flag(a):
    knater = rader[a[0]//blockSize][a[1]//blockSize]
    if knater not in åpneRuter:
        if knater not in alleFlag:
            alleFlag.append(knater)
            rect = pygame.Rect(knater[0], knater[1], blockSize, blockSize)
            pygame.draw.rect(SCREEN, "red", rect)
        else:
            alleFlag.remove(knater)
            rect = pygame.Rect(knater[0], knater[1], blockSize, blockSize)
            pygame.draw.rect(SCREEN, "dark gray", rect)
        
main()